package com.example.GestioneApplicativoMenuPizzeria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestioneApplicativoMenuPizzeriaApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestioneApplicativoMenuPizzeriaApplication.class, args);
	}

}
