package com.godFathersPizza;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GodFathersPizzaApplication {

	public static void main(String[] args) {
		SpringApplication.run(GodFathersPizzaApplication.class, args);
	}

}
