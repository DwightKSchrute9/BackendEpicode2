package com.godFathersPizza;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GodFathersPizzaApplicationTests {

	@Test
	void contextLoads() {
	}

}
